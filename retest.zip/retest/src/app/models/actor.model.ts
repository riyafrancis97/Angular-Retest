export default interface Actor {
  name: string;
  city: string;
  rating: number;
  country?: string;
}
