import { Component, OnInit, Input } from '@angular/core';
import { NgModel } from '@angular/forms';
import { Placeholder } from '@angular/compiler/src/i18n/i18n_ast';
import { ɵngStyleDirectiveDef__POST_R3__ } from '@angular/common';
import { getInterpolationArgsLength } from '@angular/compiler/src/render3/view/util';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {


  lst = []
  newid = null;
  newname = null;
  newprice=null;
  edit = null;
  changeid = null;
  changename = null;
  changeprice = null;
  selectedrow = -1;
  total = 0;


  constructor() { }

  ngOnInit() {

    this.lst = [
      { id: 101, name: 'Shilpa', price: 800 },
      { id: 102, name: 'Riya', price: 1000 },
      { id: 103, name: 'Shreya', price: 500 }
    ]
  }
  delData(n) {
    this.lst.splice(n, 1)
  }

  addData() {
    this.lst.push({ id: this.newid, name: this.newname, price: this.newprice })

  }
  editData(n) {
    this.edit = 1;
    this.selectedrow = n;

  }
  editNow(n) {
    if (n === this.selectedrow) {
      this.lst[n].id = this.changeid;
      this.lst[n].name = this.changename;
      this.lst[n].price = this.changeprice;
      this.edit = null;
    }
  }
  getTotal() {
    for (let i in this.lst) {
      this.total = this.total + this.lst[i].price
    }

  }

}
