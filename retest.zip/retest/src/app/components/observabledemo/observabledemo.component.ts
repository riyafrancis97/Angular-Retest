import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-observabledemo',
  templateUrl: './observabledemo.component.html',
  styleUrls: ['./observabledemo.component.css']
})
export class ObservabledemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
