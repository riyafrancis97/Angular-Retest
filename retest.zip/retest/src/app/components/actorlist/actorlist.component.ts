import { Component, OnInit } from '@angular/core';

import Actor from '../../models/actor.model';

import { ActordataService } from '../../services/actordata.service';

@Component({
  selector: 'app-actorlist',
  templateUrl: './actorlist.component.html',
  styleUrls: ['./actorlist.component.css']
})
export class ActorlistComponent implements OnInit {

  actorlist: Actor[];
  newActor: Actor;
  selectedIndex: number;
  tempActor: Actor;
  tempActorList: Actor[];

  constructor(private actordataService: ActordataService) { }

  ngOnInit() {
    this.actorlist = this.actordataService.getActors();
    this.newActor = {
      name: null,
      city: null,
      rating: null
    };

    this.tempActor = Object.assign({}, this.newActor);

    this.selectedIndex = -1;
    // this.tempActorList = JSON.parse(JSON.stringify(this.actorlist));
    this.tempActorList = this.actorlist.slice();
  }

  deleteActor(index) {
    // this.actorlist.splice(index, 1);
    this.actordataService.deleteActor(index);
    // console.log('Delete actor called');
  }

  addActor() {
    // this.actorlist.push(this.newActor);
    this.actordataService.addActor(this.newActor);
    this.newActor = {
      name: null,
      city: null,
      rating: null
    };
  }

  editActor(index) {
    this.selectedIndex = index;

    // Don't do this!!
    // SHALLOW COPY
    // this.tempActor = this.actorlist[index];

    // SOLUTION: DEEP COPY

    // Approach - 1 (Not Recommended)
    // this.tempActor = {
    //   name: this.actorlist[index].name,
    //   city: this.actorlist[index].city,
    //   rating: this.actorlist[index].rating
    // };

    // Approach - 2 (Not Recommended - still has the shallow copy problem)
    // this.tempActor = Object.assign({}, this.actorlist[index]);

    // Approach - 3 (Recommended approach)
    this.tempActor = JSON.parse(JSON.stringify(this.actorlist[index]));
  }

  saveActor(index) {
    this.selectedIndex = -1;
  }

  cancelEdit(index) {
    // this.actorlist[index] = this.tempActor;
    this.actordataService.updateActor(index, this.tempActor);
    this.selectedIndex = -1;
  }

  handleKey(event, index) {
    if (event.key === 'Escape') {
      this.cancelEdit(index);
    }
  }

  resetList() {
    this.actorlist = this.tempActorList.slice();
  }

  // sortList(property: string, direction: string) {
  //   this.actorlist.sort(
  //     (first, second) => {
  //       if (typeof first[property] === 'string') {
  //         // String comparison
  //         if (direction === 'ascending') {
  //           // Ascending order
  //           if (first[property] > second[property]) { return 1; }
  //           if (first[property] < second[property]) { return -1; }
  //           return 0;
  //         } else {
  //           // Descending order
  //           if (first[property] > second[property]) { return -1; }
  //           if (first[property] < second[property]) { return 1; }
  //           return 0;
  //         }
  //       } else {
  //         // Numeric comparison
  //         if (direction === 'ascending') {
  //           return first[property] - second[property];
  //         } else {
  //           return second[property] - first[property];
  //         }
  //       }
  //     }
  //   );
  // }


  // REFACTORED - V1

  // sortList(property: string, direction: string) {
  //   this.actorlist.sort(
  //     (first, second) => {
  //       if (typeof first[property] === 'string') {
  //         // String comparison
  //         if (direction === 'ascending') {
  //           // Ascending order
  //           if (first[property] > second[property]) { return 1; }
  //           if (first[property] < second[property]) { return -1; }
  //           return 0;
  //         } else {
  //           // Descending order
  //           if (first[property] > second[property]) { return -1; }
  //           if (first[property] < second[property]) { return 1; }
  //           return 0;
  //         }
  //       } else {
  //         // Numeric comparison
  //         const result = first[property] - second[property]
  //         if (direction === 'ascending') {
  //           return result;
  //         } else {
  //           return -result;
  //         }
  //       }
  //     }
  //   );
  // }

  // REFACTORED - V2

  // sortList(property: string, direction: string) {
  //   this.actorlist.sort(
  //     (first, second) => {
  //         if (direction === 'ascending') {
  //           // Ascending order
  //           if (first[property] > second[property]) { return 1; }
  //           if (first[property] < second[property]) { return -1; }
  //           return 0;
  //         } else {
  //           // Descending order
  //           if (first[property] > second[property]) { return -1; }
  //           if (first[property] < second[property]) { return 1; }
  //           return 0;
  //         }
  //     }
  //   );
  // }

  // REFACTORED V3
  sortList(property: string, direction: string) {
    this.actorlist.sort(
      (first, second) => {
        let result = 0;
        if (first[property] > second[property]) { result = 1; }
        if (first[property] < second[property]) { result = -1; }
        return (direction === 'ascending') ? result : -result;
      }
    );
  }

}
