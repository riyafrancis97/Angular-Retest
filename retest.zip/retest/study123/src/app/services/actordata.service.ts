import { Injectable } from '@angular/core';
import Actor from '../models/actor.model';

@Injectable({
  providedIn: 'root'
})
export class ActordataService {

  actorData: Actor[];

  constructor() {
    this.actorData = [
      { name: 'Amitabh Bachhan', city: 'Mumbai', rating: 9.8 },
      { name: 'Kamal Hasan', city: 'Chennai', rating: 8.5 },
      { name: 'Aishwarya Rai', city: 'Mumbai', rating: 8.6 },
      { name: 'Jennifer Lawrence', city: 'Hollywood', rating: 7.5 },
      { name: 'Rajnikant', city: 'Chennai', rating: 9.6, country: 'India' }
    ];
  }

  getActors() {
    return this.actorData;
  }

  addActor(actor: Actor) {
    this.actorData.push(actor);
  }

  deleteActor(index: number) {
    this.actorData.splice(index, 1);
  }

  updateActor(index: number, newActorData: Actor) {
    this.actorData.splice(index, 1, newActorData);
  }
}
